import { Component, OnInit } from '@angular/core';
import { Products, MyserviceService } from '../myservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-prooduct-list',
  templateUrl: './prooduct-list.component.html',
  styleUrls: ['./prooduct-list.component.css']
})
export class ProoductListComponent implements OnInit {
  message: string;
  products: Products[];
  constructor(private myservice: MyserviceService, private router: Router) { }

  ngOnInit(): any { 
    this.myservice.getProducts().subscribe(
    response => this.handleSuccessfulResponse(response),
  );
  }
  handleSuccessfulResponse(response) {
    this.products = response;
  }
  update(updateproduct: Products) {
    this.myservice.update(updateproduct);
    this.router.navigate(['/updatepro']); //updating the employee
  }
  delete(deleteproduct: Products): any {
    this.myservice.delete(deleteproduct.id).subscribe(data => {
      this.message = data
    });
    this.router.navigate(['/listpro']);
  }

}
/*import { Component, OnInit } from '@angular/core';
import { MyserviceService, Employees } from '../myservice.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-list-employee',
  templateUrl: './list-employee.component.html',
  styleUrls: ['./list-employee.component.css']
})
export class ListEmployeeComponent implements OnInit {
  message: string;
  employees: Employees[];
  constructor(private myservice: MyserviceService, private router: Router) {
  }

  ngOnInit(): any {
    this.myservice.getEmployees().subscribe(
      response => this.handleSuccessfulResponse(response),
    );
  }
  handleSuccessfulResponse(response) {
    this.employees = response;
  }
  update(updateemployee: Employees) {
    this.myservice.update(updateemployee);
    this.router.navigate(['/updateemp']); //updating the employee
  }
  delete(deleteemployee: Employees): any {
    this.myservice.delete(deleteemployee.id).subscribe(data => {
      this.message = data
    });
    this.router.navigate(['/listemp']);
  }
}
 */