import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updateproduct:   Products;
  constructor(private httpService: HttpClient) { }
  public getProducts() {
    console.log("ins service get products");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Products>("http://localhost:2341/products/GetAllProducts");
  }
  public addPro(addpro: Products) {
    console.log("ins service add");
    console.log(addpro);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:2341/products/ProductCreation", addpro,  { headers, responseType: 'text'});
  }
  public update(updateproduct: Products) {
    this.updateproduct = updateproduct;
  }
  public updateMethod() {
    return this.updateproduct;
  }
  public onUpdate(updatepro: Products) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:2341/products/UpdateProduct", updatepro,  { headers, responseType: 'text'});
  }
  delete(id: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:2341/products/DeleteProduct/" + id,  { headers, responseType: 'text'});
  }
  
}
export class Products {
  id: number;
  colour: string;
  prize: number;
  dimensions: string;
  specifications: string;
  manufacture: string;
  quantity: number;
  productCatogery: number;
  productName: string;
}
/*id;
	private int prize;
	private String colour;
	private String dimensions;
	private String specifications;
	private String manufacture;
	private int quantity;
	private int  productCatogery;
	private String productName;
	private int RetailerId; */
/* import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  updateemployee: Employees;
  constructor(private httpService: HttpClient) { }
  public getEmployees() {
    console.log("ins service get employees");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.get<Employees>("http://localhost:8586/employees/GetAllEmployees");
  }

  public addEmp(addemp: Employees) {
    console.log("ins service add");
    console.log(addemp);
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.post("http://localhost:8586/employees/EmployeeCreation", addemp,  { headers, responseType: 'text'});
  }
  
  public update(updateemployee: Employees) {
    this.updateemployee = updateemployee;
  }
  public updateMethod() {
    return this.updateemployee;
  }
  public onUpdate(updatemp: Employees) {
    console.log("ins service update");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.put("http://localhost:8586/employees/UpdateEmployee", updatemp,  { headers, responseType: 'text'});
  }
  delete(id: number) {
    console.log("ins service delete");
    const headers =new HttpHeaders().set('Content_Type', 'text/plain ;charset=utf-8');
    return this.httpService.delete("http://localhost:8586/employees/DeleteEmployee/" + id,  { headers, responseType: 'text'});
  }

}
export class Employees {
  id: number;
  name: string;
  salary: number;
  phonenumber: number;
  company: string;
}*/