import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateProoductComponent } from './update-prooduct.component';

describe('UpdateProoductComponent', () => {
  let component: UpdateProoductComponent;
  let fixture: ComponentFixture<UpdateProoductComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateProoductComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateProoductComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
